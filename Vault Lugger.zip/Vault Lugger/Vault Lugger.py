#library stuff so the game works
import copy
import random
random.seed(1)
import pygame
import pygame.freetype
import sys
from pygame.locals import *
pygame.init()
#shitloads of defined variables
font = pygame.freetype.Font('font.ttf', 18)
titleFont = pygame.freetype.Font('font.ttf', 90)
titleFont2 = pygame.freetype.Font('font.ttf', 45)
BLUE  = (0, 0, 255)
LBLUE = (0, 120, 170)
DBLUE = (0, 16, 23)
RED   = (255, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
ORANGE = (255, 130, 40)
BROWN = (140, 70, 20)
GREY = (90, 90, 90)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

BRONZE = (150,116,68)
SILVER = (192,192,192)
GOLD = (255,215,0)

coinCount = 0
life = 3
levelCount = 0
digUsed = False
pulseUsed = False
died = False
won = False
pulseCountdown = 0
mode = 'move'
chapterName = 'Royal Vaults'
doorUnlocked = False
logEntries = []
wallLoc = []
offLimits = []
offLimits2 = []
segmentLoc = []
treasureLoc = []
puzzleLoc = []
lockedDoor = []
cursorLoc = []
exitLoc = []
sentinelLoc = []
laserLoc = []
levelDataVault = [['start', 'treasure', 'treasure', 'treasure', 'puzzle', 'locked', 'exit'],
['start', 'treasure', 'treasure', 'treasure', 'puzzle', 'locked', 'exit'],
['start', 'treasure', 'treasure', 'puzzle', 'locked', 'locked', 'exit']]
surface = pygame.display.set_mode((1280, 800))
surface.fill(BLACK)
pygame.display.set_caption("Vault Lugger")
##############################

def treasure_gen(roomStartX, roomStartY, roomEndX, roomEndY, treasureNumber):
    for i in range(treasureNumber):
        rand = random.randint(0, 9)
        if rand <= 4-levelCount:
            treasureType = 'bronze'
            treasureCost = random.randint(100, 500)
        if rand >= 5-levelCount and rand <= 8-levelCount:
            treasureType = 'silver'
            treasureCost = random.randint(500, 1000)
        if rand >= 9-levelCount:
            treasureType = 'gold'
            treasureCost = random.randint(1000, 1500)
        match random.randint(0, 14):
            case 0: treasureName = 'crown'
            case 1: treasureName = 'necklace'
            case 2: treasureName = 'bracelet'
            case 3: treasureName = 'ring'
            case 4: treasureName = 'pendant'
            case 5: treasureName = 'brooch'
            case 6: treasureName = 'amulet'
            case 7: treasureName = 'chalice'
            case 8: treasureName = 'anklet'
            case 9: treasureName = 'diadem'
            case 10: treasureName = 'cameo'
            case 11: treasureName = 'emblem'
            case 12: treasureName = 'medallion'
            case 13: treasureName = 'vase'
            case 14: treasureName = 'bowl'
        treasurePos = []
        treasurePos = [random.randint(roomStartX, roomEndX), random.randint(roomStartY, roomEndY)]
        for treasure in treasureLoc:
            while treasure[:2] == treasurePos:
                treasurePos = [random.randint(roomStartX, roomEndX), random.randint(roomStartY, roomEndY)]
        treasureLoc.append([treasurePos[0], treasurePos[1], treasureType, treasureName, treasureCost])

def level_gen():
    failure = 0
    #define how many rooms we want
    roomCount = 0
    desiredRoomCount = 7
    #off limits zone on level border
    gen = [0, 0]
    #top
    while gen[0] < 39:
        offLimits.append(copy.copy(gen))
        gen[0] += 1
    #right
    while gen[1] < 39:
        offLimits.append(copy.copy(gen))
        gen[1] += 1
    #bottom
    while gen[0] > 0:
        offLimits.append(copy.copy(gen))
        gen[0] -= 1
    #left
    while gen[1] > 0:
        offLimits.append(copy.copy(gen))
        gen[1] -= 1   
    while roomCount < desiredRoomCount:
        #generate me a room
        roomSize = [random.randint(4,10), random.randint(4,10)]
        if levelDataVault[levelCount][roomCount] == 'start' or levelDataVault[levelCount][roomCount] == 'exit':
            roomSize = [3, 3]
        roomPos = [random.randint(0, 40), random.randint(0, 40)]
        while roomPos[0] + roomSize[0] + 2 > 40 or roomPos[1] + roomSize[1] + 2 > 40:
            roomPos = [random.randint(0, 40), random.randint(0, 40)]
        #check to see if intersects
        intersects = False
        for zone in offLimits:
            #top wall
            checkMade = 0
            check = copy.copy(roomPos)
            while checkMade < roomSize[0]+3:
                if check == zone: 
                    intersects = True
                    break
                check[0] += 1
                checkMade += 1
            if intersects: break
            #bottom wall
            checkMade = 0
            check = copy.copy(roomPos)
            check[1] += roomSize[1]+1
            while checkMade < roomSize[0]+3:
                if check == zone: 
                    intersects = True
                    break
                check[0] += 1
                checkMade += 1
            if intersects: break
            #left wall
            checkMade = 0
            check = copy.copy(roomPos)
            while checkMade < roomSize[0]+3:
                if check == zone: 
                    intersects = True
                    break
                check[1] += 1
                checkMade += 1
            if intersects: break
            #right wall
            checkMade = 0
            check = copy.copy(roomPos)
            check[0] += roomSize[0]+1
            while checkMade < roomSize[0]+3:
                if check == zone: 
                    intersects = True
                    break
                check[1] += 1
                checkMade += 1
            if intersects: break
        if not intersects:  
            #create a no bullshit zone
            gen = copy.copy(roomPos)
            gen[0] -= 1
            gen[1] -= 1
            rowsFilled = 0
            while rowsFilled <= roomSize[1]+4:
                zonesFilled = 0
                while zonesFilled <= roomSize[0]+4:
                    offLimits.append(copy.copy(gen))
                    gen[0] += 1
                    zonesFilled += 1
                gen[0] = copy.copy(roomPos[0])-1
                gen[1] += 1
                rowsFilled += 1
            #decide where the door is
            doorPos = [random.randint(0,3)]
            if doorPos[0] < 2: doorPos.append(random.randint(1, roomSize[0]))
            if doorPos[0] > 1: doorPos.append(random.randint(1, roomSize[1]))
            #see if door needs to be locked
            locked = False
            if levelDataVault[levelCount][roomCount] == 'locked' or levelDataVault[levelCount][roomCount] == 'exit':
                locked = True
            #draw me horizontal walls
            #top wall
            wallDrawn = 0
            gen = copy.copy(roomPos)
            while wallDrawn < roomSize[0]+2:
                if doorPos[0] == 0 and doorPos[1] == wallDrawn:
                    offLimits2.append(copy.copy(gen))
                    if locked: lockedDoor.append(copy.copy(gen))
                else:
                    wallLoc.append(copy.copy(gen))  
                gen[0] += 1
                wallDrawn += 1
            #bottom wall
            wallDrawn = 0
            gen = copy.copy(roomPos)
            gen[1] += roomSize[1]+1
            while wallDrawn < roomSize[0]+2:
                if doorPos[0] == 1 and doorPos[1] == wallDrawn:
                    offLimits2.append(copy.copy(gen))
                    if locked: lockedDoor.append(copy.copy(gen))
                else:
                    wallLoc.append(copy.copy(gen))  
                gen[0] += 1
                wallDrawn += 1
            #draw me vertical walls
            #left wall
            wallDrawn = 0
            gen = copy.copy(roomPos)
            while wallDrawn < roomSize[1]+2:
                if doorPos[0] == 2 and doorPos[1] == wallDrawn:
                    offLimits2.append(copy.copy(gen))
                    if locked: lockedDoor.append(copy.copy(gen))
                else:
                    wallLoc.append(copy.copy(gen))  
                gen[1] += 1
                wallDrawn += 1
            #right wall
            wallDrawn = 0
            gen = copy.copy(roomPos)
            gen[0] += roomSize[0]+1
            while wallDrawn < roomSize[1]+2:
                if doorPos[0] == 3 and doorPos[1] == wallDrawn:
                    offLimits2.append(copy.copy(gen))
                    if locked: lockedDoor.append(copy.copy(gen))
                else:
                    wallLoc.append(copy.copy(gen))  
                gen[1] += 1
                wallDrawn += 1
            #give me a dude
            if levelDataVault[levelCount][roomCount] == 'start':
                gen = copy.copy(roomPos)
                gen[0] += random.randint(1, roomSize[0])
                gen[1] += random.randint(1, roomSize[1])
                segmentLoc.append(gen)
            #give me treasure
            if levelDataVault[levelCount][roomCount] == 'treasure':
                treasure_gen(roomPos[0]+1, roomPos[1]+1, roomPos[0]+roomSize[0], roomPos[1]+roomSize[1], 3+levelCount)
            #give me puzzle
            if levelDataVault[levelCount][roomCount] == 'puzzle':
                roomStartX, roomStartY, roomEndX, roomEndY = roomPos[0]+1, roomPos[1]+1, roomPos[0]+roomSize[0], roomPos[1]+roomSize[1]
                puzzleLoc.append([random.randint(roomStartX, roomEndX), random.randint(roomStartY, roomEndY)])
                while len(puzzleLoc) < 7+levelCount:
                    newPuzzle = [random.randint(roomStartX, roomEndX), random.randint(roomStartY, roomEndY)]
                    noOverlap = True
                    for puzzle in puzzleLoc:
                        if newPuzzle == puzzle:
                            noOverlap = False
                            break
                    if noOverlap:
                        for puzzle in puzzleLoc:    
                            if [newPuzzle[0]-1, newPuzzle[1]] == puzzle:
                                puzzleLoc.append(newPuzzle)
                                break
                            if [newPuzzle[0]+1, newPuzzle[1]] == puzzle:
                                puzzleLoc.append(newPuzzle)
                                break
                            if [newPuzzle[0], newPuzzle[1]-1] == puzzle:
                                puzzleLoc.append(newPuzzle)
                                break
                            if [newPuzzle[0], newPuzzle[1]+1] == puzzle:
                                puzzleLoc.append(newPuzzle)
                                break
            #give me big treasure
            if levelDataVault[levelCount][roomCount] == 'locked':
                treasure_gen(roomPos[0]+1, roomPos[1]+1, roomPos[0]+roomSize[0], roomPos[1]+roomSize[1], 6+levelCount)
            #give me level exit
            if levelDataVault[levelCount][roomCount] == 'exit':
                roomStartX, roomStartY, roomEndX, roomEndY = roomPos[0]+1, roomPos[1]+1, roomPos[0]+roomSize[0], roomPos[1]+roomSize[1]
                exitLoc.append([random.randint(roomStartX, roomEndX), random.randint(roomStartY, roomEndY)])
            roomCount += 1
        else:
            failure += 1
            if failure == 1000: return 'fail'
    #give me sentinels
    offset = 0
    sentinelCount = 0
    desiredSentinelCount = 3+levelCount
    while sentinelCount < desiredSentinelCount:
        collision = True
        while collision:
            fail = False
            gen = [random.randrange(0,39,2), random.randrange(0,39,2)]
            for zone in offLimits:
                if gen == zone: 
                    fail = True
                    break
            for sentinel in sentinelLoc:
                if gen == sentinel: 
                    fail = True
                    break
            if not fail: collision = False
        sentinelLoc.append(gen)
        sentinelCount += 1
    #give me lasers
    for sentloc in sentinelLoc:    
        #up laser
        collision = False
        lasgen = copy.copy(sentloc)
        lasgen.append(offset)
        while not collision:
            fail = False
            lasgen[1] -= 1
            if lasgen[1] < 0 or lasgen[1] > 39: fail = True
            for wall in wallLoc:
                if lasgen[:2] == wall: 
                    fail = True
                    break
            for sentinel in sentinelLoc:
                if lasgen[:2] == sentinel: 
                    fail = True
                    break
            for door in offLimits2:
                if lasgen[:2] == door: 
                    fail = True
                    break
            if fail: 
                collision = True
            else:
                laserLoc.append(copy.copy(lasgen))
        #down laser
        collision = False
        lasgen = copy.copy(sentloc)
        lasgen.append(offset)
        while not collision:
            fail = False
            lasgen[1] += 1
            if lasgen[1] < 0 or lasgen[1] > 39: fail = True
            for wall in wallLoc:
                if lasgen[:2] == wall: 
                    fail = True
                    break
            for sentinel in sentinelLoc:
                if lasgen[:2] == sentinel: 
                    fail = True
                    break
            for door in offLimits2:
                if lasgen[:2] == door: 
                    fail = True
                    break
            if fail: 
                collision = True
            else:
                laserLoc.append(copy.copy(lasgen))
        #left laser
        collision = False
        lasgen = copy.copy(sentloc)
        lasgen.append(offset)
        while not collision:
            fail = False
            lasgen[0] -= 1
            if lasgen[0] < 0 or lasgen[0] > 39: fail = True
            for wall in wallLoc:
                if lasgen[:2] == wall: 
                    fail = True
                    break
            for sentinel in sentinelLoc:
                if lasgen[:2] == sentinel: 
                    fail = True
                    break
            for door in offLimits2:
                if lasgen[:2] == door: 
                    fail = True
                    break
            if fail: 
                collision = True
            else:
                laserLoc.append(copy.copy(lasgen))
        #right laser
        collision = False
        lasgen = copy.copy(sentloc)
        lasgen.append(offset)
        while not collision:
            fail = False
            lasgen[0] += 1
            if lasgen[0] < 0 or lasgen[0] > 39: fail = True
            for wall in wallLoc:
                if lasgen[:2] == wall: 
                    fail = True
                    break
            for sentinel in sentinelLoc:
                if lasgen[:2] == sentinel: 
                    fail = True
                    break
            for door in offLimits2:
                if lasgen[:2] == door: 
                    fail = True
                    break
            if fail: 
                collision = True
            else:
                laserLoc.append(copy.copy(lasgen))
        if offset == 0: 
            offset = 1
        else:
            offset = 0

    log_gen('Welcome to level '+str(levelCount+1)+' of the '+chapterName+'!', 'message')
    stat_gen()                
                


##############################
def stat_gen():
    global coinCount
    surface.fill(BLACK, rect = Rect(800, 0, 480, 400))
    font.render_to(surface, [800, 20], 'Life: '+str(life), fgcolor = WHITE)
    font.render_to(surface, [800, 60], 'Level: '+'Royal Vaults '+str(levelCount+1), fgcolor = WHITE)
    font.render_to(surface, [800, 100], 'Coin: '+str(coinCount), fgcolor = WHITE)
    font.render_to(surface, [800, 160], 'Abilities:', fgcolor = WHITE)
    font.render_to(surface, [800, 200], '(drains 1 life per use:)', fgcolor = WHITE)
    font.render_to(surface, [800, 220], '  [B]reakout - converts all bags into treasure.', fgcolor = WHITE)
    font.render_to(surface, [800, 240], '(usable once per level:)', fgcolor = WHITE)
    font.render_to(surface, [800, 260], '  [D]ig - destroys all adjacent walls.', fgcolor = WHITE)
    font.render_to(surface, [800, 280], '  [P]ulse - halts all sentinels for 3 turns.', fgcolor = WHITE)

def log_gen(entry, type):
    looked = False
    surface.fill(BLACK, rect = Rect(800, 400, 480, 400))
    match type:
        case 'loot':
            logEntries.append('Collected a '+entry[2]+' '+entry[3]+' worth '+str(entry[4])+' coin.')
        case 'look':
            font.render_to(surface, [800,400], "You see:", fgcolor = WHITE)
            font.render_to(surface, [800,400+20], entry, fgcolor = WHITE)
            looked = True
        case 'message':
            logEntries.append(entry)
    if not looked:
        if len(logEntries) > 20: del logEntries[0]
        offset = 0
        for entries in logEntries:
            font.render_to(surface, [800,400+offset], entries, fgcolor = WHITE)
            offset += 20
##############################

def move(direction):
    global coinCount, lockedDoor, cursorLoc, doorUnlocked, levelCount, life, pulseCountdown
    moved = True
    moveTick = False
    lootCalled = False
    collided = False
    match direction:
        case 'L':
            XorY = 0
            movement = 1
        case 'R':
            XorY = 0
            movement = -1
        case 'U':
            XorY = 1
            movement = 1
        case 'D':
            XorY = 1
            movement = -1
    if mode == 'move':
        playerLoc = copy.copy(segmentLoc[0])
        playerLoc[XorY] -= movement
        if playerLoc[XorY] < 0 or playerLoc[XorY] > 39 or playerLoc[XorY] > 39:
            playerLoc[XorY] += movement
            moved = False 
            collided = True
            log_gen("Can't collide with walls!", 'message')    
        for wall in wallLoc:
            if playerLoc == wall:
                playerLoc[XorY] += movement
                moved = False
                collided = True
                log_gen("Can't collide with walls!", 'message')
                break
        for door in lockedDoor:
            if playerLoc == door:
                playerLoc[XorY] += movement
                moved = False
                collided = True
                log_gen("Can't collide with walls!", 'message')
                break
        for sentinel in sentinelLoc:
            if playerLoc == sentinel:
                playerLoc[XorY] += movement
                moved = False
                collided = True
                log_gen("Can't collide with sentinels!", 'message')
                break
        if not collided:
            for exit in exitLoc:
                if playerLoc == exit: return 'switch'
            for segment in segmentLoc:
                if playerLoc == segment[:2] and not (playerLoc == segmentLoc[-1][:2] and len(segmentLoc) != 2):
                    playerLoc[XorY] += 1 
                    log_gen("Can't collide with your bags!", 'message')
                    moved = False 
                    break 
            for treasure in treasureLoc:
                if playerLoc == treasure[:2]:
                    lootedTreasure = treasure
                    treasureLoc.remove(treasure)
                    lootCalled = True   
                    break  
        if moved:
            moveTick = True
            for laser in laserLoc:
                if playerLoc == laser[:2]:
                    if laser[2] == 1 and pulseCountdown == 0:
                        life -= 1
                        if life == 0: return 'death'
                        log_gen("You are hit by the beam!", 'message')
                        stat_gen()
                    if laser[2] == 0 and pulseCountdown != 0:
                        life -= 1
                        if life == 0: return 'death'
                        log_gen("You are hit by the beam!", 'message')
                        stat_gen()
            if lootCalled:
                lootedTreasure[0], lootedTreasure[1] = segmentLoc[0][0], segmentLoc[0][1]
                segmentLoc[0][0], segmentLoc[0][1] = playerLoc[0], playerLoc[1]
                segmentLoc.insert(1, lootedTreasure)
                log_gen(lootedTreasure, 'loot')
                coinCount += lootedTreasure[4]
                stat_gen()
            else:
                oldLoc = playerLoc
                for i in range(len(segmentLoc)):
                    segmentLoc[i][0], segmentLoc[i][1], oldLoc = oldLoc[0], oldLoc[1], [segmentLoc[i][0], segmentLoc[i][1]]
            pressedPuzzle = 0
            for puzzle in puzzleLoc:
                for segment in segmentLoc:
                    if segment[:2] == puzzle: pressedPuzzle += 1
            if pressedPuzzle == 7+levelCount and not doorUnlocked: 
                lockedDoor = []
                log_gen('You hear a loud click and distant rumbling!', 'message')
                doorUnlocked = True
    elif mode == 'look':
        logCalled = False
        cursorLoc[XorY] -= movement
        if cursorLoc[XorY] < 0 or cursorLoc[XorY] > 39 or cursorLoc[XorY] > 39:
            cursorLoc[XorY] += movement
            moved = False   
        if moved: 
            overlayed = False
            for segment in segmentLoc:
                if cursorLoc == segment[:2]:
                    if cursorLoc == segmentLoc[0]:
                        log_gen("Yourself.", 'look')
                        logCalled = True
                        overlayed = True
                        break
                    else: 
                        log_gen('A bag with a '+segment[2]+' '+segment[3]+' worth '+str(segment[4])+' coin.', 'look')
                        logCalled = True
                        overlayed = True
                        break 
            for laser in laserLoc:
                if cursorLoc == laser[:2]:
                    if laser[2] == 1:
                        log_gen("A cloud of harmless energy particles.", 'look')
                        logCalled = True
                        break
            for laser in laserLoc:
                if cursorLoc == laser[:2]:
                    if laser[2] == 0:
                        log_gen("An active disintegration beam.", 'look')
                        logCalled = True
                        break
            for sentinel in sentinelLoc:
                if cursorLoc == sentinel:
                    log_gen("An automatic turret firing disintegration beams.", 'look')
                    logCalled = True
                    overlayed = True
                    break
            if not overlayed:
                for treasure in treasureLoc:
                    if cursorLoc == treasure[:2]:
                        log_gen('A '+treasure[2]+' '+treasure[3]+' worth '+str(treasure[4])+' coin.', 'look')
                        logCalled = True
                        break
                for wall in wallLoc:
                    if cursorLoc == wall:
                        log_gen("A sturdy looking stone wall.", 'look')
                        logCalled = True
                        break
                for door in lockedDoor:
                    if cursorLoc == door:
                        log_gen("A flimsy looking stone wall...", 'look')
                        logCalled = True
                        break
                for exit in exitLoc:
                    if cursorLoc == exit:
                        log_gen("A portal to a deeper level.", 'look')
                        logCalled = True
                        break
                for puzzle in puzzleLoc:
                    if cursorLoc == puzzle:
                        log_gen("A large pressure plate.", 'look')
                        logCalled = True
                        break
            if not logCalled: log_gen("Nothing.", 'look')
    grid_gen()
    pygame.display.update()
    if moveTick: return 'tick'

def grid_gen():
    surface.fill(BLACK, rect = Rect(0, 0, 800, 800))
    for object in laserLoc:
        if object[2] == 1:
            surface.fill(DBLUE, rect = Rect(object[0]*20, object[1]*20, 20, 20)) 
    for object in laserLoc:
        if object[2] == 0:
            surface.fill(LBLUE, rect = Rect(object[0]*20, object[1]*20, 20, 20)) 
    for object in sentinelLoc:
        surface.fill(BLUE, rect = Rect(object[0]*20, object[1]*20, 20, 20))  
    for object in exitLoc:
        surface.fill(ORANGE, rect = Rect(object[0]*20, object[1]*20, 20, 20))    
    for object in puzzleLoc:
        surface.fill(GREY, rect = Rect(object[0]*20, object[1]*20, 20, 20))
    for object in wallLoc:
        surface.fill(WHITE, rect = Rect(object[0]*20, object[1]*20, 20, 20))
    for object in treasureLoc:
        if object[2] == 'bronze':
            surface.fill(BRONZE, rect = Rect(object[0]*20, object[1]*20, 20, 20))
        if object[2] == 'silver':
            surface.fill(SILVER, rect = Rect(object[0]*20, object[1]*20, 20, 20))
        if object[2] == 'gold':
            surface.fill(GOLD, rect = Rect(object[0]*20, object[1]*20, 20, 20))
    for object in lockedDoor:
        surface.fill(WHITE, rect = Rect(object[0]*20, object[1]*20, 20, 20))
    for object in segmentLoc:
        if object[:2] == segmentLoc[0]:
            surface.fill(GREEN, rect = Rect(object[0]*20, object[1]*20, 20, 20))
        else:
            surface.fill(BROWN, rect = Rect(object[0]*20, object[1]*20, 20, 20))    
    if mode == 'look': 
        surface.fill(RED, rect = Rect(cursorLoc[0]*20, cursorLoc[1]*20, 10, 10))

##############################
titleScreen = True
titleFont.render_to(surface, [320,25], 'Vault Lugger', fgcolor = WHITE)
titleFont2.render_to(surface, [335,125], 'An exercise in futility', fgcolor = WHITE)
titleFont2.render_to(surface, [370,500], 'Press ENTER to start', fgcolor = WHITE)
pygame.display.update()
failSafe = 1
while failSafe == 1:
    if level_gen() == 'fail': 
        doorUnlocked = False
        wallLoc = []
        offLimits = []
        offLimits2 = []
        segmentLoc = []
        treasureLoc = []
        puzzleLoc = []
        lockedDoor = []
        exitLoc = []
        sentinelLoc = []
        laserLoc = []
    else:
        failSafe = 0
grid_gen()  
while True:
    ticked = False
    levelSwitch = False
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN and titleScreen:
            match event.key:
                case pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                case pygame.K_RETURN:
                    if died or won:
                        pygame.quit()
                        sys.exit()
                    titleScreen = False
                    pygame.display.update()
        if event.type == pygame.KEYDOWN and not titleScreen:
            if event.mod & pygame.KMOD_SHIFT:
                match event.key:
                    case pygame.K_b:
                        if len(segmentLoc) > 1 and life != 0:
                            life -= 1
                            if life == 0: 
                                died = True
                                break
                            for segment in segmentLoc:
                                if segment != segmentLoc[0]:
                                    coinCount -= segment[4]
                                    treasureLoc.append(segment)
                            segmentLoc = [segmentLoc[0]]
                            stat_gen()
                            grid_gen()
                            pygame.display.update()
                    case pygame.K_d:
                        if not digUsed:
                            #left
                            playerLoc = copy.copy(segmentLoc[0])
                            playerLoc[0] -= 1
                            for wall in wallLoc:
                                if playerLoc == wall: 
                                    wallLoc.remove(wall)  
                            #right
                            playerLoc = copy.copy(segmentLoc[0])
                            playerLoc[0] += 1
                            for wall in wallLoc:
                                if playerLoc == wall: 
                                    wallLoc.remove(wall)
                            #up
                            playerLoc = copy.copy(segmentLoc[0])
                            playerLoc[1] -= 1
                            for wall in wallLoc:
                                if playerLoc == wall: 
                                    wallLoc.remove(wall)
                            #down
                            playerLoc = copy.copy(segmentLoc[0])
                            playerLoc[1] += 1
                            for wall in wallLoc:
                                if playerLoc == wall: 
                                    wallLoc.remove(wall)
                            digUsed = True
                            log_gen("Dig activated!", 'message')
                            grid_gen()
                            pygame.display.update()
                        else:
                            log_gen("Dig is on cooldown.", 'message')
                            pygame.display.update()
                    case pygame.K_p:
                        if not pulseUsed:
                            pulseCountdown = 3
                            pulseUsed = True
                            log_gen("Pulse activated!", 'message')
                            pygame.display.update()
                        else:
                            log_gen("Pulse is on cooldown.", 'message')
                            pygame.display.update()
            match event.key: 
                case pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                case pygame.K_UP:
                    moveMode = move('U')
                    if moveMode == 'switch': levelSwitch = True
                    if moveMode == 'tick': ticked = True
                    if moveMode == 'death': died = True
                case pygame.K_DOWN:
                    moveMode = move('D')
                    if moveMode == 'switch': levelSwitch = True 
                    if moveMode == 'tick': ticked = True
                    if moveMode == 'death': died = True
                case pygame.K_LEFT:
                    moveMode = move('L')
                    if moveMode == 'switch': levelSwitch = True
                    if moveMode == 'tick': ticked = True
                    if moveMode == 'death': died = True
                case pygame.K_RIGHT:
                    moveMode = move('R')
                    if moveMode == 'switch': levelSwitch = True
                    if moveMode == 'tick': ticked = True
                    if moveMode == 'death': died = True
                case pygame.K_l:
                    if mode == 'move': 
                        mode = 'look'
                        cursorLoc = copy.copy(segmentLoc[0])
                        surface.fill(RED, rect = Rect(segmentLoc[0][0]*20, segmentLoc[0][1]*20, 10, 10))
                        log_gen("Yourself.", 'look')
                        pygame.display.update()
                    elif mode == 'look': 
                        mode = 'move'
                        log_gen('blank', 'blank')
                        cursorLoc = []
                        grid_gen()
                        pygame.display.update()
    if died:
        titleScreen = True
        surface.fill(BLACK)
        titleFont.render_to(surface, [410,25], 'You died', fgcolor = WHITE)
        titleFont2.render_to(surface, [430,125], 'Coin collected:', fgcolor = WHITE)
        titleFont2.render_to(surface, [430,225], str(coinCount), fgcolor = WHITE)
        titleFont2.render_to(surface, [385,500], 'Press ENTER to exit', fgcolor = WHITE)
        pygame.display.update()
    if levelSwitch:
        levelCount += 1
        if levelCount < 3:
            doorUnlocked = False
            digUsed = False
            pulseUsed = False
            wallLoc = []
            offLimits = []
            offLimits2 = []
            segmentLoc = []
            treasureLoc = []
            puzzleLoc = []
            lockedDoor = []
            exitLoc = []
            sentinelLoc = []
            laserLoc = []
            failSafe = 1
            while failSafe == 1:
                if level_gen() == 'fail': 
                    doorUnlocked = False
                    digUsed = False
                    pulseUsed = False
                    wallLoc = []
                    offLimits = []
                    offLimits2 = []
                    segmentLoc = []
                    treasureLoc = []
                    puzzleLoc = []
                    lockedDoor = []
                    exitLoc = []
                    sentinelLoc = []
                    laserLoc = []
                else:
                    failSafe = 0
            grid_gen()
            pygame.display.update()
        else: won = True
    if won:
        titleScreen = True
        surface.fill(BLACK)
        titleFont.render_to(surface, [410,25], 'You won!', fgcolor = WHITE)
        titleFont2.render_to(surface, [430,125], 'Coin collected:', fgcolor = WHITE)
        titleFont2.render_to(surface, [430,225], str(coinCount), fgcolor = WHITE)
        titleFont2.render_to(surface, [385,500], 'Press ENTER to exit', fgcolor = WHITE)
        pygame.display.update()
    if ticked and not levelSwitch:
        if pulseCountdown == 0:
            for laser in laserLoc:
                if laser[2] == 0: 
                    laser[2] = 1
                else:
                    laser[2] = 0
        else:
            pulseCountdown -= 1
        grid_gen()
        pygame.display.update()