import pygame
import sys
from pygame.locals import *
import random
random.seed()
pygame.init()
font = pygame.freetype.Font('font.ttf', 50)
font2 = pygame.freetype.Font('font.ttf', 35)
FPS = 30
FramePerSec = pygame.time.Clock()
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

CYAN = (128, 255, 255)
BLUE = (0, 0, 255)
ORANGE = (255, 128, 0)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
PURPLE = (128, 0, 255)
RED = (255, 0, 0)

length = 10
width = 20
surface = pygame.display.set_mode((length*30*2, width*30))
surface.fill(BLACK)
pygame.display.set_caption("Tetris")

tetrominoes = ["I", "J", "L", "O", "S", "T", "Z"]
bag = []
variant = None
rotation = 0
staticPieces = []
activePieces = []
ghost = []
heldTetromino = []

score = 0
level = 1
linesCleared = 0
fallTimerOld = None
held = False
holdPiece = None
usedHold = False
firstHold = True
mediator = None
fallTimer = 1000
combo = False


def ghost_piece():
    global ghost
    del ghost
    ghost = []
    for piece in activePieces:
        ghost.append(piece[:])
    blocked = False
    while not blocked:
        for piece in ghost:
            piece[1] += 1
        for piece in ghost:
            if piece[1] > 19:
                blocked = True
                break
            for staticPiece in staticPieces:
                if piece[0] == staticPiece[0] and piece[1] == staticPiece[1]:
                    blocked = True
                    break
            if blocked:
                break
    for piece in ghost:
        piece[1] -= 1
    match ghost[0][2]:
        case (128, 255, 255):
            for piece in ghost:
                piece[2] = (64, 128, 128)
        case (0, 0, 255):
            for piece in ghost:
                piece[2] = (0, 0, 128)
        case (255, 128, 0):
            for piece in ghost:
                piece[2] = (128, 64, 0)
        case (255, 255, 0):
            for piece in ghost:
                piece[2] = (128, 128, 0)
        case (0, 255, 0):
            for piece in ghost:
                piece[2] = (0, 128, 0)
        case (128, 0, 255):
            for piece in ghost:
                piece[2] = (64, 0, 128)
        case (255, 0, 0):
            for piece in ghost:
                piece[2] = (128, 0, 0)


def grid_gen():
    surface.fill(BLACK)
    for piece in ghost:
        surface.fill(piece[2], rect=Rect(piece[0]*30, piece[1]*30, 30, 30))
    for piece in staticPieces:
        surface.fill(piece[2], rect=Rect(piece[0]*30, piece[1]*30, 30, 30))
    for piece in activePieces:
        surface.fill(piece[2], rect=Rect(piece[0]*30, piece[1]*30, 30, 30))
    surface.fill(WHITE, rect=Rect(300, 0, 300, 600))
    font.render_to(surface, [395, 10], "HOLD", fgcolor=BLACK)
    for piece in heldTetromino:
        surface.fill(piece[2], rect=Rect((piece[0]+10)*30, (piece[1]+2)*30, 30, 30))
    font.render_to(surface, [395, 210], "NEXT", fgcolor=BLACK)
    for piece in nextTetromino:
        surface.fill(piece[2], rect=Rect((piece[0] + 10) * 30, (piece[1] + 9) * 30, 30, 30))
    font2.render_to(surface, [310, 400], "SCORE: " + str(score), fgcolor=BLACK)
    font2.render_to(surface, [310, 550], "LEVEL: " + str(level), fgcolor=BLACK)


def bag_gen():
    global bag
    bag = tetrominoes[:]
    random.shuffle(bag)


bag_gen()


def tetromino_gen(tetromino=None, replace=False):
    global rotation, variant, usedHold
    usedHold = False
    if not replace:
        tetromino = bag[0]
        bag.pop(0)
        if not bag:
            bag_gen()
    given = give_tetromino(tetromino)
    for piece in given:
        activePieces.append(piece)
    #game over; let's hope it actually works
    #check if the freshly spawned piece collides with any other blocks - if it does, shut it all down
    for piece in activePieces:
        for staticPiece in staticPieces:
            if piece[0] == staticPiece[0] and piece[1] == staticPiece[1]:
                pygame.quit()
                sys.exit()
    rotation = 0
    variant = tetromino


def give_tetromino(tetromino):
    i = []
    match tetromino:
        case "I":
            i.append([3, 0, CYAN, False])
            i.append([4, 0, CYAN, True])
            i.append([5, 0, CYAN, False])
            i.append([6, 0, CYAN, False])
        case "J":
            i.append([3, 0, BLUE, False])
            i.append([3, 1, BLUE, False])
            i.append([4, 1, BLUE, True])
            i.append([5, 1, BLUE, False])
        case "L":
            i.append([5, 0, ORANGE, False])
            i.append([3, 1, ORANGE, False])
            i.append([4, 1, ORANGE, True])
            i.append([5, 1, ORANGE, False])
        case "O":
            i.append([4, 0, YELLOW, False])
            i.append([5, 0, YELLOW, False])
            i.append([4, 1, YELLOW, False])
            i.append([5, 1, YELLOW, False])
        case "S":
            i.append([4, 0, GREEN, False])
            i.append([5, 0, GREEN, False])
            i.append([3, 1, GREEN, False])
            i.append([4, 1, GREEN, True])
        case "T":
            i.append([4, 0, PURPLE, False])
            i.append([3, 1, PURPLE, False])
            i.append([4, 1, PURPLE, True])
            i.append([5, 1, PURPLE, False])
        case "Z":
            i.append([3, 0, RED, False])
            i.append([4, 0, RED, False])
            i.append([4, 1, RED, True])
            i.append([5, 1, RED, False])
    return i


tetromino_gen()
nextTetromino = give_tetromino(bag[0])


def move(direction):
    global rotation, activePieces
    if direction == "R":
        for piece in activePieces:
            piece[0] += 1
        for piece in activePieces:
            if piece[0] > 9:
                for piece2 in activePieces:
                    piece2[0] -= 1
                return None
        for piece in activePieces:
            for staticPiece in staticPieces:
                if piece[0] == staticPiece[0] and piece[1] == staticPiece[1]:
                    for piece2 in activePieces:
                        piece2[0] -= 1
                    return None
    if direction == "L":
        for piece in activePieces:
            piece[0] -= 1
        for piece in activePieces:
            if piece[0] < 0:
                for piece2 in activePieces:
                    piece2[0] += 1
                return None
        for piece in activePieces:
            for staticPiece in staticPieces:
                if piece[0] == staticPiece[0] and piece[1] == staticPiece[1]:
                    for piece2 in activePieces:
                        piece2[0] += 1
                    return None
    if direction == "spin":
        if variant != "O":
            axis = None
            newTetromino = []
            for piece in activePieces:
                if piece[3]:
                    axis = piece[:]
                    break
            match variant:
                case "I":
                    match rotation:
                        case 0:
                            axis[0] += 1
                            newTetromino.append(axis)
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                            newTetromino.append([axis[0], axis[1]+2, axis[2], False])
                        case 1:
                            axis[1] += 1
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]-2, axis[1], axis[2], False])
                        case 2:
                            axis[0] -= 1
                            newTetromino.append(axis)
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0], axis[1]-2, axis[2], False])
                        case 3:
                            axis[1] -= 1
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]+2, axis[1], axis[2], False])
                case "J":
                    match rotation:
                        case 0:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                        case 1:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1]+1, axis[2], False])
                        case 2:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                            newTetromino.append([axis[0]-1, axis[1]+1, axis[2], False])
                        case 3:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                case "L":
                    match rotation:
                        case 0:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1]+1, axis[2], False])
                        case 1:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]-1, axis[1]+1, axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                        case 2:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                        case 3:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1]-1, axis[2], False])
                case "S":
                    match rotation:
                        case 0:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1]+1, axis[2], False])
                        case 1:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                            newTetromino.append([axis[0]-1, axis[1]+1, axis[2], False])
                        case 2:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                        case 3:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1]-1, axis[2], False])
                case "T":
                    match rotation:
                        case 0:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                        case 1:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                        case 2:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                        case 3:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                case "Z":
                    match rotation:
                        case 0:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1]-1, axis[2], False])
                        case 1:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0], axis[1]+1, axis[2], False])
                            newTetromino.append([axis[0]+1, axis[1]+1, axis[2], False])
                        case 2:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]-1, axis[1], axis[2], False])
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0]-1, axis[1]+1, axis[2], False])
                        case 3:
                            newTetromino.append(axis)
                            newTetromino.append([axis[0]+1, axis[1], axis[2], False])
                            newTetromino.append([axis[0], axis[1]-1, axis[2], False])
                            newTetromino.append([axis[0]-1, axis[1]-1, axis[2], False])
            rotFailed = False
            for piece in newTetromino:
                if piece[0] < 0 or piece[0] > 9:
                    rotFailed = True
                    break
            if not rotFailed:
                for piece in newTetromino:
                    for staticPiece in staticPieces:
                        if piece[0] == staticPiece[0] and piece[1] == staticPiece[1]:
                            rotFailed = True
                            break
            if not rotFailed:
                rotation += 1
                if rotation == 4:
                    rotation = 0
                del activePieces
                activePieces = newTetromino
    if direction == "drop":
        blocked = False
        while not blocked:
            for piece in activePieces:
                piece[1] += 1
            for piece in activePieces:
                if piece[1] > 19:
                    blocked = True
                    break
                for staticPiece in staticPieces:
                    if piece[0] == staticPiece[0] and piece[1] == staticPiece[1]:
                        blocked = True
                        break
                if blocked:
                    break
        for piece in activePieces:
            piece[1] -= 1
        fallen()


def fall():
    for piece in activePieces:
        piece[1] += 1
    for piece in activePieces:
        if piece[1] > 19:
            for piece2 in activePieces:
                piece2[1] -= 1
            fallen()
            return None
    for piece in activePieces:
        for staticPiece in staticPieces:
            if piece[0] == staticPiece[0] and piece[1] == staticPiece[1]:
                for piece2 in activePieces:
                    piece2[1] -= 1
                fallen()
                return None


def fallen():
    global activePieces, linesCleared, score, level, fallTimer, held, combo, nextTetromino
    for piece in activePieces:
        staticPieces.append(piece)
    activePieces = []
    tetromino_gen()
    nextTetromino = give_tetromino(bag[0])

    rowsCleared = []
    lineCleared = False
    for i in range(20):
        filtered = []
        iterator = filter(lambda piece: piece[1] == i, staticPieces)
        for piece in iterator:
            filtered.append(piece)
        if len(filtered) == 10:
            lineCleared = True
            rowsCleared.append(i)
            for piece in filtered:
                staticPieces.remove(piece)
    if lineCleared:
        for row in rowsCleared:
            for piece in staticPieces:
                if not piece[1] > row:
                    piece[1] += 1
    linesCleared += len(rowsCleared)
    match len(rowsCleared):
        case 1:
            score += 100*level
            combo = False
        case 2:
            score += 300*level
            combo = False
        case 3:
            score += 500*level
            combo = False
        case 4:
            if combo:
                score += 1200*level
            else:
                score += 800*level
                combo = True
    if linesCleared > 9:
        linesCleared -= 10
        level += 1
        if held:
            fallTimer = fallTimerOld
            held = False
        # baby mode on
        if fallTimer > 200:
            fallTimer -= 100
        pygame.time.set_timer(pygame.USEREVENT, fallTimer)


def hold():
    global holdPiece, activePieces, usedHold, firstHold, mediator, heldTetromino, nextTetromino
    if not usedHold:
        mediator = variant
        activePieces = []
        if firstHold:
            tetromino_gen()
            nextTetromino = give_tetromino(bag[0])
        else:
            tetromino_gen(holdPiece, replace=True)
        holdPiece = mediator
        heldTetromino = give_tetromino(holdPiece)
        usedHold = True
        firstHold = False


pygame.mixer.music.load("korobeiniki.mp3")
pygame.mixer.music.play(-1)
pygame.time.set_timer(pygame.USEREVENT, fallTimer)
while True:
    keys = pygame.key.get_pressed()
    if keys[K_DOWN]:
        if not held:
            fall()
            fallTimerOld = fallTimer
            fallTimer = 100
            held = True
            pygame.time.set_timer(pygame.USEREVENT, fallTimer)
    else:
        if held:
            fallTimer = fallTimerOld
            pygame.time.set_timer(pygame.USEREVENT, fallTimer)
            held = False
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.USEREVENT:
            fall()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                move("spin")
            if event.key == pygame.K_SPACE:
                move("drop")
            if event.key == pygame.K_LEFT:
                move("L")
            if event.key == pygame.K_RIGHT:
                move("R")
            if event.key == pygame.K_c:
                hold()
    ghost_piece()
    grid_gen()
    pygame.display.update()
    FramePerSec.tick(FPS)
