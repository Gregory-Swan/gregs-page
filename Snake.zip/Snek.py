import copy
import random
random.seed()
import pygame
import sys
from pygame.locals import *
pygame.init()
FPS = 5
FramePerSec = pygame.time.Clock()
BLUE  = (0, 0, 255)
RED   = (255, 0, 0)
GREEN = (0, 255, 0)
WHITE = (255, 255, 255)
length = 20
width = 10
surface = pygame.display.set_mode((length*50, width*50))
surface.fill(WHITE)
pygame.display.set_caption("Snek")
segmentLoc = [[random.randrange(5, length-5), random.randrange(2, width-2)]]
movement = 'R'
fruitLoc = [random.randrange(0, length), random.randrange(0, width)]
while fruitLoc == segmentLoc:
    fruitLoc = [random.randrange(0, length), random.randrange(0, width)]
def grid_gen(): 
    surface.fill(WHITE)
    gen = [0, 0]
    while gen[1] <= width:
        while gen[0] <= length:
            for segment in segmentLoc:
                if gen == segment:
                    if segment == segmentLoc[0]:
                        surface.fill(RED, rect = Rect(gen[0]*50, gen[1]*50, 50, 50))
                    else:
                        surface.fill(BLUE, rect = Rect(gen[0]*50, gen[1]*50, 50, 50))
            if gen == fruitLoc:
                surface.fill(GREEN, rect = Rect(gen[0]*50, gen[1]*50, 50, 50))
            gen[0] += 1
        gen[0] = 0
        gen[1] += 1
def move():
    eatCalled = False
    playerLoc = copy.copy(segmentLoc[0])
    if movement == 'L':
        if playerLoc[0] != 0:
            playerLoc[0] -= 1
            if playerLoc == fruitLoc:
                eatCalled = True 
            for segment in segmentLoc:
                if playerLoc == segment and playerLoc != segmentLoc[-1]:
                    pygame.quit()
                    sys.exit()   
        else:
            pygame.quit()
            sys.exit()  
    elif movement == 'R':
        if playerLoc[0] != length-1:
            playerLoc[0] += 1
            if playerLoc == fruitLoc:
                eatCalled = True
            for segment in segmentLoc:
                if playerLoc == segment and playerLoc != segmentLoc[-1]:
                    pygame.quit()
                    sys.exit() 
        else:
            pygame.quit()
            sys.exit()
    elif movement == 'U':
        if playerLoc[1] != 0:
            playerLoc[1] -= 1
            if playerLoc == fruitLoc:
                eatCalled = True
            for segment in segmentLoc:
                if playerLoc == segment and playerLoc != segmentLoc[-1]:
                    pygame.quit()
                    sys.exit() 
        else:
            pygame.quit()
            sys.exit()
    elif movement == 'D':
        if playerLoc[1] != width-1:
            playerLoc[1] += 1
            if playerLoc == fruitLoc:
                eatCalled = True
            for segment in segmentLoc:
                if playerLoc == segment and playerLoc != segmentLoc[-1]:
                    pygame.quit()
                    sys.exit() 
        else:
            pygame.quit()
            sys.exit()
    segmentLoc.insert(0, playerLoc)
    if eatCalled == False:
        del segmentLoc[-1]
    else:
        return True
def eat(): 
    spaceTaken = False
    freeSpace = []
    gen = [0, 0]
    while gen[1] <= width-1:
        while gen[0] <= length-1:
            for segment in segmentLoc:
                if gen == segment:
                    spaceTaken = True
            if spaceTaken == False:
                freeSpace.append(copy.copy(gen))
            spaceTaken = False
            gen[0] += 1       
        gen[0] = 0
        gen[1] += 1
    if len(freeSpace) > 1:
        fruitLoc = freeSpace[random.randrange(0, len(freeSpace))]
    elif len(freeSpace) == 0:
        fruitLoc = [-1, -1]
    else:
        fruitLoc = freeSpace[0]
    return fruitLoc        
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                if movement != 'D' or len(segmentLoc) == 1:
                    movement = 'U'
                    break    
            if event.key == pygame.K_DOWN:
                if movement != 'U' or len(segmentLoc) == 1:
                    movement = 'D'
                    break  
            if event.key == pygame.K_LEFT:
                if movement != 'R' or len(segmentLoc) == 1:
                    movement = 'L'
                    break  
            if event.key == pygame.K_RIGHT:
                if movement != 'L' or len(segmentLoc) == 1:
                    movement = 'R'
                    break 
    if move():
        fruitLoc = eat()
    grid_gen()
    pygame.display.update()
    FramePerSec.tick(FPS)